package com.example.darkambient;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import java.io.*;
import java.util.Random;

/** Small offline procedural dark-ambient synthesizer. Audio is generated as 16-bit mono PCM. */
public final class AmbientEngine {
    public static final int RATE = 44100;
    private volatile boolean playing = false;
    private Thread playThread;
    private AudioTrack track;
    private volatile float space = 0.72f;
    private volatile float darkness = 0.62f;
    private volatile float pulse = 0.24f;

    public void setSpace(float v) { space = clamp(v); }
    public void setDarkness(float v) { darkness = clamp(v); }
    public void setPulse(float v) { pulse = clamp(v); }
    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    public synchronized void play() {
        if (playing) return;
        playing = true;
        playThread = new Thread(() -> {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(min, 8192)).setTransferMode(AudioTrack.MODE_STREAM).build();
            track.play();
            short[] buffer = new short[2048];
            long sample = 0;
            while (playing) {
                synth(buffer, sample);
                track.write(buffer, 0, buffer.length);
                sample += buffer.length;
            }
            try { track.stop(); } catch (Exception ignored) {}
            track.release(); track = null;
        }, "AmbientAudio");
        playThread.start();
    }

    public synchronized void stop() {
        playing = false;
        if (track != null) { try { track.pause(); track.flush(); } catch (Exception ignored) {} }
    }

    private void synth(short[] out, long offset) {
        double t; double amp; double val;
        double spaceNow = space, darkNow = darkness, pulseNow = pulse;
        for (int i=0;i<out.length;i++) {
            long n = offset + i; t = n / (double) RATE;
            // Slow, slightly detuned sub-drone with a soft upper harmonic.
            double f = 48.999 + darkNow * 9.0;
            double drone = Math.sin(2*Math.PI*f*t) * 0.42 + Math.sin(2*Math.PI*(f*1.503)*t) * 0.10;
            drone += Math.sin(2*Math.PI*(f*2.01)*t + Math.sin(t*0.07)*0.7) * 0.045;
            // Sparse notes from a minor/modal palette; each note fades in and out slowly.
            double notes = 0;
            int[] semis = {0, 3, 5, 7, 10, 12, 15, 19};
            for (int k=0;k<3;k++) {
                double period = 13.0 + k*7.3;
                double local = (t + k*5.17) % period;
                int idx = (int)((t/period*3 + k*2) % semis.length);
                double nf = 110.0 * Math.pow(2.0, semis[idx]/12.0);
                double env = Math.pow(Math.max(0, Math.sin(Math.PI*local/period)), 2.0) * (0.14 + spaceNow*0.17);
                notes += Math.sin(2*Math.PI*nf*t + Math.sin(t*0.11+k)*0.5) * env;
                notes += Math.sin(2*Math.PI*(nf*1.002)*t) * env * 0.25;
            }
            double slowPulse = 0.5 + 0.5*Math.sin(2*Math.PI*(0.045 + pulseNow*0.12)*t);
            double throb = Math.sin(2*Math.PI*(70+darkNow*25)*t) * pulseNow * 0.07 * slowPulse;
            // A lightweight feedback-like delay creates a spacious tail without external assets.
            double shimmer = Math.sin(2*Math.PI*(f*3.01)*t + Math.sin(t*0.19)) * spaceNow * 0.025;
            val = (drone*(0.72 + 0.18*slowPulse) + notes + throb + shimmer) * 0.62;
            val = Math.tanh(val * 1.4);
            amp = Math.min(1.0, Math.max(-1.0, val));
            out[i] = (short)(amp * 32767);
        }
    }

    /** Writes a 45-second procedural composition to a standards-compliant PCM WAV file. */
    public File renderWav(File file) throws IOException {
        final int seconds = 45;
        final int totalSamples = RATE * seconds;
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(file))) {
            writeWavHeader(out, totalSamples * 2);
            short[] buffer = new short[4096];
            for (int pos=0; pos<totalSamples;) {
                int count = Math.min(buffer.length, totalSamples-pos);
                if (count != buffer.length) buffer = new short[count];
                synth(buffer, pos);
                for (short s : buffer) { out.write(s & 0xff); out.write((s >> 8) & 0xff); }
                pos += count;
            }
        }
        return file;
    }
    private static void writeWavHeader(OutputStream out, int dataBytes) throws IOException {
        out.write(new byte[]{'R','I','F','F'}); le32(out, 36+dataBytes); out.write(new byte[]{'W','A','V','E','f','m','t',' '});
        le32(out,16); le16(out,1); le16(out,1); le32(out,RATE); le32(out,RATE*2); le16(out,2); le16(out,16);
        out.write(new byte[]{'d','a','t','a'}); le32(out,dataBytes);
    }
    private static void le16(OutputStream o,int v)throws IOException{o.write(v&255);o.write((v>>8)&255);}
    private static void le32(OutputStream o,int v)throws IOException{o.write(v&255);o.write((v>>8)&255);o.write((v>>16)&255);o.write((v>>24)&255);}
}
