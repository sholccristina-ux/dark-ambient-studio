package com.example.darkambient;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private final AmbientEngine engine = new AmbientEngine();
    private TextView status;
    private Button playButton;
    private boolean isPlaying = false;
    private int scene = 0;
    private final String[] scenes = {"01  ·  Туманный лес", "02  ·  Заброшенный храм", "03  ·  Глубокий космос", "04  ·  Ночной ритуал"};
    private final float[][] presets = {{0.82f,0.58f,0.18f},{0.94f,0.78f,0.28f},{0.66f,0.42f,0.12f},{0.78f,0.88f,0.55f}};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(9,11,19));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(26),dp(22),dp(30)); scroll.addView(root);

        TextView eyebrow = text("AMBIENT SOUND LAB  /  001", 11, 0xFF9B8CFF, false);
        eyebrow.setLetterSpacing(0.12f); root.addView(eyebrow);
        TextView title = text("DARK\nAMBIENT", 38, 0xFFF1F0FA, true);
        title.setLineSpacing(0,0.93f); LinearLayout.LayoutParams tp = params(); tp.topMargin=dp(10); root.addView(title,tp);
        TextView subtitle = text("Создавай музыку из тишины.", 15, 0xFF9CA3B7, false); tp=params(); tp.topMargin=dp(8); root.addView(subtitle,tp);

        View orb = new View(this) { android.graphics.Paint p = new android.graphics.Paint(3); @Override protected void onDraw(android.graphics.Canvas c) { super.onDraw(c); float x=getWidth()/2f,y=getHeight()/2f; p.setShader(new android.graphics.RadialGradient(x,y,Math.min(x,y),new int[]{0xFF6B5CBB,0x55362D70,0x00362D70},null,android.graphics.Shader.TileMode.CLAMP)); c.drawCircle(x,y,Math.min(x,y),p); p.setShader(null); p.setColor(0x887F75D9); p.setStyle(android.graphics.Paint.Style.STROKE); p.setStrokeWidth(dp(1)); c.drawCircle(x,y,Math.min(x,y)*0.72f,p); p.setStyle(android.graphics.Paint.Style.FILL); }};
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1,dp(170)); op.topMargin=dp(8); root.addView(orb,op);

        TextView sceneLabel = section("ВЫБЕРИ АТМОСФЕРУ"); root.addView(sceneLabel);
        TextView sceneName = text(scenes[scene],18,0xFFF1F0FA,true); tp=params(); tp.topMargin=dp(8); root.addView(sceneName,tp);
        LinearLayout sceneRow = new LinearLayout(this); sceneRow.setOrientation(LinearLayout.HORIZONTAL); tp=params(); tp.topMargin=dp(12); root.addView(sceneRow,tp);
        for (int i=0;i<4;i++) { final int index=i; Button b=button("0"+(i+1)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(48),1); bp.setMargins(0,0,dp(8),0); sceneRow.addView(b,bp); b.setOnClickListener(v->{scene=index; sceneName.setText(scenes[index]); engine.setSpace(presets[index][0]);engine.setDarkness(presets[index][1]);engine.setPulse(presets[index][2]);}); }

        root.addView(section("НАСТРОЙ ЗВУК"));
        addSlider(root,"Пространство и эхо",72, v->engine.setSpace(v/100f));
        addSlider(root,"Темнота звучания",62, v->engine.setDarkness(v/100f));
        addSlider(root,"Пульсация",24, v->engine.setPulse(v/100f));

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); tp=params();tp.topMargin=dp(22);root.addView(actions,tp);
        playButton=button("▶  СЛУШАТЬ"); playButton.setBackground(round(0xFF9B8CFF,dp(14))); playButton.setTextColor(0xFF100F20); playButton.setTextSize(14); playButton.setTypeface(null,Typeface.BOLD);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(56),1.2f);ap.setMargins(0,0,dp(9),0);actions.addView(playButton,ap);
        Button export=button("↓  MP3"); export.setBackground(round(0xFF25283A,dp(14))); export.setTextColor(0xFFF1F0FA); export.setTextSize(14); export.setTypeface(null,Typeface.BOLD); actions.addView(export,new LinearLayout.LayoutParams(0,dp(56),0.8f));
        playButton.setOnClickListener(v->{ if(!isPlaying){engine.play();isPlaying=true;playButton.setText("■  ОСТАНОВИТЬ");status.setText("ЗВУК ВОСПРОИЗВОДИТСЯ  ·  НАЖМИ, ЧТОБЫ ОСТАНОВИТЬ");}else{engine.stop();isPlaying=false;playButton.setText("▶  СЛУШАТЬ");status.setText("ГОТОВ К СОЗДАНИЮ");}});
        export.setOnClickListener(v->exportMp3(export));
        status=text("ГОТОВ К СОЗДАНИЮ",11,0xFF9B8CFF,true); status.setGravity(Gravity.CENTER); tp=params();tp.topMargin=dp(20);root.addView(status,tp);
        TextView footer=text("ГЕНЕРАТИВНЫЙ ЗВУК  ·  БЕЗ ИНТЕРНЕТА",10,0xFF686F86,false);footer.setGravity(Gravity.CENTER);tp=params();tp.topMargin=dp(22);root.addView(footer,tp);
        setContentView(scroll);
    }

    private interface SliderChange { void onChange(int v); }
    private void addSlider(LinearLayout root,String label,int initial,SliderChange callback){
        TextView t=text(label,14,0xFFD4D6E5,false);LinearLayout.LayoutParams p=params();p.topMargin=dp(18);root.addView(t,p);
        SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress(initial);s.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF9B8CFF));s.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFE1DCFF));p=params();p.topMargin=dp(3);root.addView(s,p);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){callback.onChange(v);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});callback.onChange(initial); }
    private TextView section(String s){TextView t=text(s,11,0xFF777F99,true);t.setLetterSpacing(0.08f);LinearLayout.LayoutParams p=params();p.topMargin=dp(22);return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(0xFFE5E6F2);b.setBackground(round(0xFF25283A,dp(12)));return b;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private LinearLayout.LayoutParams params(){return new LinearLayout.LayoutParams(-1,-2);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}

    private void exportMp3(Button export) {
        export.setEnabled(false); status.setText("СОЗДАЮ КОМПОЗИЦИЮ…");
        new Thread(()->{
            File wav=null, mp3=null;
            try {
                File dir=getCacheDir(); wav=new File(dir,"ambient_render.wav"); mp3=new File(dir,"Dark_Ambient_Studio.mp3");
                engine.renderWav(wav);
                String cmd="-y -hide_banner -loglevel error -i \""+wav.getAbsolutePath()+"\" -codec:a libmp3lame -qscale:a 3 -metadata title=Dark_Ambient_Studio \""+mp3.getAbsolutePath()+"\"";
                com.arthenica.ffmpegkit.FFmpegSession session=FFmpegKit.execute(cmd);
                if(!ReturnCode.isSuccess(session.getReturnCode()) || !mp3.exists() || mp3.length()<1000) throw new Exception("MP3 encoder did not complete: "+session.getFailStackTrace());
                ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,"Dark_Ambient_Studio.mp3");values.put(MediaStore.MediaColumns.MIME_TYPE,"audio/mpeg");
                if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_MUSIC+"/Dark Ambient Studio");
                Uri uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("Could not create media file");
                try(FileInputStream in=new FileInputStream(mp3);OutputStream out=getContentResolver().openOutputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
                final Uri saved=uri;runOnUiThread(()->{status.setText("MP3 СОХРАНЁН В ПАПКЕ MUSIC");Toast.makeText(this,"Готово! MP3 сохранён в Music / Dark Ambient Studio",Toast.LENGTH_LONG).show();Intent share=new Intent(Intent.ACTION_SEND);share.setType("audio/mpeg");share.putExtra(Intent.EXTRA_STREAM,saved);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Поделиться композицией"));export.setEnabled(true);});
            } catch(Exception e){String message=e.getMessage()==null?"Неизвестная ошибка":e.getMessage();runOnUiThread(()->{status.setText("НЕ УДАЛОСЬ СОХРАНИТЬ MP3");Toast.makeText(this,"Экспорт не выполнен: "+message,Toast.LENGTH_LONG).show();export.setEnabled(true);});}
            finally {if(wav!=null)wav.delete();if(mp3!=null)mp3.delete();}
        },"AmbientExport").start();
    }
    @Override protected void onDestroy(){engine.stop();super.onDestroy();}
}
