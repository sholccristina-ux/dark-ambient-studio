# Dark Ambient Studio (Android)

A small, offline-first procedural dark-ambient music generator intended for Android phones such as the Samsung Galaxy S25 Ultra.

## Implemented in source
- Native Android UI with four starting atmospheres and three simple sound controls.
- Procedural audio synthesis: low drone, slow minor/modal notes, gentle pulsing and a soft synthetic shimmer.
- Live playback using Android `AudioTrack`.
- 45-second offline render to PCM WAV, followed by MP3 encoding through FFmpegKit/libmp3lame.
- MP3 is copied to `Music/Dark Ambient Studio` using MediaStore and can be shared from the system chooser.

## Important build status
This workspace did not have the Android SDK, Gradle, or network access to download build tools/dependencies. Therefore an APK could not be compiled or device-tested here. This archive is the Android Studio source project, **not an installable APK**. Do not rename it to `.apk`.

The original FFmpegKit binaries were removed from Maven Central. This project now uses the community-maintained drop-in replacement `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9`; its API is intended to remain compatible, but a successful build and MP3 export still need to be verified.

## Build in Android Studio
1. Install a current Android Studio release with Android SDK Platform 35 and JDK 17 or newer.
2. Open this folder as a project.
3. Let Gradle sync and resolve the FFmpegKit dependency.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the resulting debug APK on the Galaxy S25 Ultra and test playback, export, and output file location.

## Known limitations of v0.1
- The first version is a procedural sound sketch generator, not a full multitrack DAW.
- Export duration is fixed at 45 seconds.
- Sound generation is intentionally simple; the current “space” control changes the tone palette/shimmer rather than using a convolution reverb engine.
- MP3 export depends on the external FFmpegKit binary dependency and has not been verified in a build in this environment.
